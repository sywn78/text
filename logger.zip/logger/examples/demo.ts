/**
 * demo.ts — Logger 使用示例
 *
 * 本文件展示 Logger 系统全部 API 的典型用法。
 * 可直接通过 `npx tsx demo.ts` 运行。
 */

import { Logger, LogLevel, ConsoleWriter, FileWriter } from "../src";

// ── 1. 基础用法 ────────────────────────────────────────────
console.log("=== 1. 基础用法 ===");

const logger = new Logger(LogLevel.Verbose);
logger.addWriter(new ConsoleWriter("[MyApp]"));

logger.verbose("正在初始化数据库连接...");
logger.info("服务已启动，端口 3000");
logger.warning("检测到 API 响应延迟超过 2s");
logger.error(new Error("数据库连接超时"));

// ── 2. 多 Writer 模式（同时输出到 console 和文件） ───────────
console.log("\n=== 2. 多 Writer 模式 ===");

const multiLogger = new Logger(LogLevel.Info);
multiLogger
  .addWriter(new ConsoleWriter("[MyApp]"))
  .addWriter(new FileWriter("/var/log/myapp.log", 5)); // 每 5 条刷盘

multiLogger.info("多 Writer 模式生效");
multiLogger.warning("这条会同时出现在控制台和文件中");
// verbose 级别低于全局阈值 Info，将被过滤
multiLogger.verbose("这条不会被输出");

// 触发 FileWriter 的显式 flush
multiLogger.dispose();

// ── 3. 运行时等级切换 ─────────────────────────────────────
console.log("\n=== 3. 运行时等级切换 ===");

const toggleLogger = new Logger(LogLevel.Error) // 只记录 Error
  .addWriter(new ConsoleWriter("[Alert]"));

toggleLogger.info("这条 INFO 会被过滤");
toggleLogger.warning("这条 WARNING 也会被过滤");
toggleLogger.error("这条 ERROR 正常输出");

// 动态降低阈值
toggleLogger.setLevel(LogLevel.Info);
toggleLogger.info("现在 INFO 也能输出了");

// ── 4. 结构化日志 ─────────────────────────────────────
console.log("\n=== 4. 结构化日志 ===");

const jsonLogger = new Logger(LogLevel.Info).addWriter(new ConsoleWriter("[API]"));
jsonLogger.info({
  event: "payment.success",
  orderId: "ORD-2024-001",
  amount: 299.99,
  currency: "CNY",
});

// ── 5. Writer 移除 ─────────────────────────────────────
console.log("\n=== 5. Writer 移除 ===");

const removable = new Logger(LogLevel.Info);
const tempWriter = new ConsoleWriter("[TEMP]");
removable.addWriter(tempWriter);
removable.info("这条会输出");
removable.removeWriter(tempWriter);
removable.info("这条不会输出，因为没有 Writer 了");

console.log("\n=== 演示完成 ===");
