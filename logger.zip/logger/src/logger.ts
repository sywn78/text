/**
 * Logger — 核心日志记录器
 *
 * 职责：
 *   1. 持有一组 ILogWriter 实例（console、文件、远程等）
 *   2. 根据全局最低等级过滤日志
 *   3. 将非字符串数据序列化为字符串
 *   4. 为每条日志注入时间戳等元数据
 *
 * 线程安全性：本实现为同步单线程模型，不处理竞态。
 * 如需在多线程 / Web Worker 中使用，应在 Logger 外部加锁。
 */
import { LogLevel, logLevelLabel } from "./log-level";
import type { ILogWriter, LogMeta } from "./writers/ilog-writer";

export class Logger {
  /** 注册在此 Logger 中的写入器列表 */
  private writers: ILogWriter[] = [];

  /** 全局最低日志等级 —— 低于此等级的日志将被丢弃 */
  private minimumLevel: LogLevel;

  /** 是否已销毁（阻止销毁后继续写入） */
  private disposed = false;

  constructor(minimumLevel: LogLevel = LogLevel.Verbose) {
    this.minimumLevel = minimumLevel;
  }

  // ── 写入器管理 ──────────────────────────────────────────

  /**
   * 添加一个写入器。所有写入器都会收到入站日志（无独占模式）。
   * 典型用法：同时注册 ConsoleWriter 和 FileWriter。
   */
  addWriter(writer: ILogWriter): this {
    if (this.disposed) {
      console.warn("[Logger] 已销毁，拒绝添加 Writer");
      return this;
    }
    this.writers.push(writer);
    return this;
  }

  /**
   * 移除指定写入器。
   * 注意：仅移除引用；Writer 的销毁由其调用方负责。
   */
  removeWriter(writer: ILogWriter): this {
    this.writers = this.writers.filter((w) => w !== writer);
    return this;
  }

  // ── 等级控制 ────────────────────────────────────────────

  /** 动态调整日志等级（运行时关闭 verbose 等） */
  setLevel(level: LogLevel): void {
    this.minimumLevel = level;
  }

  getLevel(): LogLevel {
    return this.minimumLevel;
  }

  // ── 写入方法 ────────────────────────────────────────────

  /**
   * 统一入口：序列化数据 → 等级过滤 → 注入元数据 → 扇出到所有 Writer。
   */
  private log(level: LogLevel, data: unknown): void {
    if (this.disposed) return;
    if (level < this.minimumLevel) return;

    const message = typeof data === "string" ? data : safeStringify(data);
    const meta: LogMeta = { timestamp: new Date().toISOString() };

    for (const writer of this.writers) {
      try {
        writer.write(level, message, meta);
      } catch (err) {
        // Writer 抛错不应中断其他 Writer 或应用主流程
        console.warn("[Logger] Writer 写入失败:", err);
      }
    }
  }

  /** 调试/追踪信息 — 仅开发时开启 */
  verbose(data: unknown): void {
    this.log(LogLevel.Verbose, data);
  }

  /** 常规运行时信息 */
  info(data: unknown): void {
    this.log(LogLevel.Info, data);
  }

  /** 非致命异常 */
  warning(data: unknown): void {
    this.log(LogLevel.Warning, data);
  }

  /** 致命错误 */
  error(data: unknown): void {
    this.log(LogLevel.Error, data);
  }

  /**
   * 便捷方法 —— 由调用方指定等级，避免外部依赖 logLevelLabel。
   * 可直接传入 LogLevel 枚举或字符串。
   */
  logAt(level: LogLevel, data: unknown): void {
    this.log(level, data);
  }

  // ── 生命周期 ───────────────────────────────────────────

  /**
   * 销毁 Logger：触发各 Writer 的清理（如 FileWriter.flush），
   * 然后清空 Writer 列表并标记为已销毁。
   */
  dispose(): void {
    if (this.disposed) return;

    for (const writer of this.writers) {
      if ("flush" in writer && typeof (writer as any).flush === "function") {
        (writer as any).flush();
      }
    }
    this.writers = [];
    this.disposed = true;
  }
}

/**
 * 将任意值安全地序列化为字符串。
 *
 * 策略：
 *   1. 原始值 → 直接 String()
 *   2. Error  → 提取 message + stack
 *   3. 对象   → JSON.stringify（带循环引用保护）
 */
function safeStringify(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (value == null) return String(value);

  if (value instanceof Error) {
    return value.stack ? `${value.message}\n${value.stack}` : value.message;
  }

  try {
    return JSON.stringify(value);
  } catch {
    // 循环引用等无法序列化的情况
    return String(value);
  }
}
