/**
 * FileWriter — 将日志写入文件。
 *
 * 当前使用模拟的 NativeFileWriteSync，仅用于展示架构的扩展能力。
 * 替换为真实的 fs.writeFileSync 或 Deno.writeTextFileSync 即可投入生产。
 */
import type { ILogWriter, LogMeta } from "./ilog-writer";
import { LogLevel, logLevelLabel } from "../log-level";

/**
 * 模拟的原生文件写入函数。
 * 生产环境应替换为：
 *   - Node.js:   import { writeFileSync } from "node:fs";
 *   - 浏览器:    File System Access API (showDirectoryPicker)
 *   - Deno:      Deno.writeTextFileSync(filePath, buffer);
 */
function NativeFileWriteSync(filePath: string, buffer: string): void {
  console.log(`[File IO ${filePath}] ${buffer}`);
}

export class FileWriter implements ILogWriter {
  /** 累积缓冲区，减少 I/O 频率 */
  private buffer: string[] = [];

  /**
   * @param filePath  日志文件路径
   * @param flushThreshold 缓冲区达到此行数时自动刷盘，默认 1（每条即时写入）
   */
  constructor(
    private readonly filePath: string,
    private readonly flushThreshold: number = 1,
  ) {}

  write(level: LogLevel, message: string, _meta?: LogMeta): void {
    const label = logLevelLabel(level);
    this.buffer.push(`[${label}] ${message}`);

    if (this.buffer.length >= this.flushThreshold) {
      this.flush();
    }
  }

  /**
   * 强制将缓冲区内所有日志写入文件。
   * 也应在应用退出前调用（如 process.on("exit")）。
   */
  flush(): void {
    if (this.buffer.length === 0) return;

    const payload = this.buffer.join("\n") + "\n";
    NativeFileWriteSync(this.filePath, payload);
    this.buffer = [];
  }
}
