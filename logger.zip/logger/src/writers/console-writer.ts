/**
 * ConsoleWriter — 将日志输出至浏览器 / Node.js 控制台。
 *
 * 根据日志等级自动选择合适的 console 方法：
 *   Verbose → console.debug
 *   Info    → console.log
 *   Warning → console.warn
 *   Error   → console.error
 */
import type { ILogWriter, LogMeta } from "./ilog-writer";
import { LogLevel } from "../log-level";

export class ConsoleWriter implements ILogWriter {
  /**
   * 可选的前缀字符串，会添加到每条日志之前。
   * 例如 "[MyApp]" → "[MyApp] [INFO] 服务已启动"
   */
  constructor(private readonly prefix: string = "") {}

  write(level: LogLevel, message: string, meta?: LogMeta): void {
    const timestamp = meta?.timestamp ?? new Date().toISOString();
    const prefixPart = this.prefix ? `${this.prefix} ` : "";
    const line = `${timestamp} ${prefixPart}${message}`;

    switch (level) {
      case LogLevel.Verbose:
        console.debug(line);
        break;
      case LogLevel.Info:
        console.log(line);
        break;
      case LogLevel.Warning:
        console.warn(line);
        break;
      case LogLevel.Error:
        console.error(line);
        break;
    }
  }
}
