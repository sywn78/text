/**
 * ILogWriter — 日志写入器接口
 *
 * 所有输出目标的抽象契约。未来新增输出源（文件、网络、
 * 第三方监控平台）时，只需实现该接口即可无缝接入 Logger。
 */
import type { LogLevel } from "../log-level";

export interface ILogWriter {
  /**
   * 写入一条日志条目。
   *
   * @param level   - 日志等级
   * @param message - 日志内容（已序列化为字符串）
   * @param meta    - 可选的附加元数据（时间戳、调用栈等）
   */
  write(level: LogLevel, message: string, meta?: LogMeta): void;
}

/**
 * 日志条目附带的元数据。
 * 当前为最小定义，未来可扩展（如 traceId、userId 等）。
 */
export interface LogMeta {
  /** ISO 8601 时间戳，由 Logger 在调用 write 前注入 */
  timestamp: string;
}
