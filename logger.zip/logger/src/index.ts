/**
 * logger — 轻量级 TypeScript 日志系统
 *
 * 入口文件：统一导出所有公共 API。
 */
export { Logger } from "./logger";
export { LogLevel, logLevelLabel } from "./log-level";
export { ConsoleWriter } from "./writers/console-writer";
export { FileWriter } from "./writers/file-writer";
export type { ILogWriter, LogMeta } from "./writers/ilog-writer";
