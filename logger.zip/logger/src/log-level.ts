/**
 * LogLevel — 日志等级枚举
 *
 * 等级从低到高排列，数值上递增。这样可以用简单的数值比较
 * 来判断某条日志是否达到写入器的阈值。
 */
export enum LogLevel {
  /** 最详细的调试/追踪信息，仅开发环境启用 */
  Verbose = 0,
  /** 常规运行时信息（如"服务已启动"） */
  Info = 1,
  /** 非致命的异常或潜在问题（如"重试第 3 次"） */
  Warning = 2,
  /** 致命错误，需要对运维人员告警 */
  Error = 3,
}

/**
 * 将 LogLevel 枚举值转换为可读字符串。
 * 主要用于输出格式化。
 */
export function logLevelLabel(level: LogLevel): string {
  switch (level) {
    case LogLevel.Verbose:
      return "VERBOSE";
    case LogLevel.Info:
      return "INFO";
    case LogLevel.Warning:
      return "WARNING";
    case LogLevel.Error:
      return "ERROR";
  }
}
