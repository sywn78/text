# Logger — 轻量级 TypeScript 日志系统

一套面向 Web 应用的日志记录器，支持多等级、多输出目标和灵活的 Writer 架构。

## 目录结构

```
logger/
  src/
    log-level.ts              # LogLevel 枚举定义
    logger.ts                 # 核心 Logger 类
    index.ts                  # 统一导出（barrel export）
    writers/
      ilog-writer.ts          # ILogWriter 接口 & LogMeta 类型
      console-writer.ts       # 输出至浏览器 / Node.js 控制台
      file-writer.ts          # 输出至文件（当前为模拟实现）
      index.ts                # writers 子模块导出
  examples/
    demo.ts                   # 完整使用示例
  tsconfig.json
  README.md
```

## 设计理念

**接口隔离。** 日志记录器本身不关心输出目的地。所有输出目标都必须实现 `ILogWriter` 接口。Logger 只负责等级过滤、数据序列化、元数据注入和扇出分发——具体的 format、transport、persistence 全部委托给 Writer。

**组合优于继承。** 一个 Logger 可以挂载多个 Writer（console + file + remote），运行时增删，互不干扰。这避免了传统"Logger 继承树"的脆弱性。

**等级即数值。** `LogLevel` 枚举的值从小到大对应严重程度，因此只需简单的大于比较即可完成过滤，无需额外的查找表或映射。

**Writer 抛错不影响其他输出。** 每个 Writer 调用包裹在 try/catch 中，单个 Writer 故障不会阻断其他 Writer 或应用主流程。

**不做日志轮转（在本层）。** 日志轮转、归档、压缩属于存储层的关注点，应由 FileWriter 内部或外部调度器处理，而非 Logger 核心。

## 快速开始

```ts
import { Logger, LogLevel, ConsoleWriter } from "./src";

// 创建 Logger，最低输出等级为 Verbose
const logger = new Logger(LogLevel.Verbose);

// 挂载控制台输出
logger.addWriter(new ConsoleWriter("[MyApp]"));

// 记录日志
logger.info("服务已启动，端口 3000");
logger.warning("API 响应延迟 > 2s");
logger.error(new Error("数据库连接超时"));
```

控制台输出：

```
2026-06-22T08:30:00.000Z [MyApp] [INFO]    服务已启动，端口 3000
2026-06-22T08:30:01.000Z [MyApp] [WARNING] API 响应延迟 > 2s
2026-06-22T08:30:01.500Z [MyApp] [ERROR]   数据库连接超时
```

## 多 Writer 模式

同时输出到控制台和文件：

```ts
import { Logger, LogLevel, ConsoleWriter, FileWriter } from "./src";

const logger = new Logger(LogLevel.Info)
  .addWriter(new ConsoleWriter("[MyApp]"))
  .addWriter(new FileWriter("/var/log/myapp.log", 5)); // 每 5 条刷盘

logger.info("多 Writer 同步记录");

// 应用退出前销毁 Logger，触发 FileWriter 的 flush
process.on("exit", () => logger.dispose());
```

## 运行时等级切换

```ts
const logger = new Logger(LogLevel.Error) // 生产环境：只记录 Error
  .addWriter(new ConsoleWriter("[Prod]"));

// 需要排查问题时临时降低阈值
logger.setLevel(LogLevel.Verbose);
logger.verbose("详细诊断信息……");

// 排查完毕后恢复
logger.setLevel(LogLevel.Error);
```

## API 参考

### Logger

| 方法 | 说明 |
|------|------|
| `constructor(minLevel?)` | 创建 Logger，默认 Verbose |
| `addWriter(writer)` | 注册输出目标，返回 this（链式调用） |
| `removeWriter(writer)` | 移除输出目标，返回 this |
| `setLevel(level)` | 运行时调整最低等级 |
| `getLevel()` | 获取当前最低等级 |
| `verbose(data)` | 记录 Verbose 级别日志 |
| `info(data)` | 记录 Info 级别日志 |
| `warning(data)` | 记录 Warning 级别日志 |
| `error(data)` | 记录 Error 级别日志 |
| `logAt(level, data)` | 由调用方指定等级 |
| `dispose()` | 触发所有 Writer 清理（flush），标记为已销毁 |

### LogLevel

| 枚举值 | 数值 | 含义 |
|--------|------|------|
| `Verbose` | 0 | 详细调试/追踪信息 |
| `Info` | 1 | 常规运行时信息 |
| `Warning` | 2 | 非致命异常 |
| `Error` | 3 | 致命错误 |

### ConsoleWriter

```ts
new ConsoleWriter(prefix?: string)
```

按等级映射 console 方法：Verbose→debug, Info→log, Warning→warn, Error→error。

### FileWriter

```ts
new FileWriter(filePath: string, flushThreshold?: number)
```

默认 `flushThreshold = 1`（每条立即刷盘）。增大阈值可减少 I/O 次数。

生产环境需将 `NativeFileWriteSync` 替换为真实的文件写入 API（见 `src/writers/file-writer.ts` 中的注释）。

## 未来扩展指南

### 添加新的输出目标

实现 `ILogWriter` 接口即可：

```ts
import { ILogWriter, LogMeta } from "./ilog-writer";
import { LogLevel } from "../log-level";

export class RemoteWriter implements ILogWriter {
  constructor(private readonly endpoint: string) {}

  write(level: LogLevel, message: string, meta?: LogMeta): void {
    fetch(this.endpoint, {
      method: "POST",
      body: JSON.stringify({ level, message, meta }),
    }).catch(() => {}); // 静默失败，不阻塞主流程
  }
}
```

然后注册：

```ts
logger.addWriter(new RemoteWriter("https://log.example.com/ingest"));
```

### 添加日志格式化

当前格式化逻辑内嵌在 Writer 中。如需统一格式，可抽取 `ILogFormatter` 接口：

```ts
interface ILogFormatter {
  format(level: LogLevel, message: string, meta: LogMeta): string;
}
```

让 Logger 持有一个 formatter，在调用 `write` 前先格式化。

### 日志轮转

在 `FileWriter` 内部添加文件大小检查和轮转逻辑：

```ts
write(level, message, meta) {
  if (this.currentFileSize > this.maxFileSize) {
    this.rotate();
  }
  this.buffer.push(...);
}
```

### 结构化日志 / 上下文传播

扩展 `LogMeta` 以支持 traceId、spanId、userId 等分布式追踪字段：

```ts
interface LogMeta {
  timestamp: string;
  traceId?: string;
  spanId?: string;
  userId?: string;
}
```

配合 AsyncLocalStorage（Node.js）或 Zone.js（浏览器）实现自动上下文传播。

### 浏览器环境适配

`ConsoleWriter` 已兼容浏览器。`FileWriter` 在生产环境中可替换为 File System Access API (`showDirectoryPicker`)。

## 设计模式总结

| 模式 | 应用 |
|------|------|
| Strategy Pattern | `ILogWriter` — 不同 Writer 是可互换的策略 |
| Composite Pattern | Logger 持有多个 Writer，对外呈现为单一 Logger |
| Template Method | `log()` 私有方法是模板：过滤→序列化→元数据→扇出 |
| Chain of Responsibility | 每个 Writer 独立决策如何处置日志条目 |
